﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport(@"f:\Teaching\2015-2016\Term2\KTPM-TH13\Teaching\16-04-13\MyDLL\Debug\MyDLL.dll")]
        private static extern int fnMyDLL();
        private void button1_Click(object sender, EventArgs e)
        {
            int kq = fnMyDLL();
            MessageBox.Show(kq.ToString());
        }
    }
}
